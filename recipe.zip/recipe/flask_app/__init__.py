from flask import Flask, render_template,redirect,request,session

from flask_app.models.recipe import Recipe
from flask_app.models.user import User

app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe'

from flask_bcrypt import Bcrypt        
bcrypt = Bcrypt(app) 
