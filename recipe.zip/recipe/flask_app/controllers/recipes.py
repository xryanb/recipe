from flask import render_template,request, redirect,session,flash
from flask_app import app
from flask_app.models.user import User
from flask_app.models.recipe import Recipe
from flask_app.controllers import users

import re
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/login', methods=['POST'])
def login():
    data={
        "email":request.form['email']
    }
    real_user=User.get_one_by_email(data)

    if not real_user:
        flash('Invalid Email/Password!','err_user_email_log')
        return redirect('/')
    if not bcrypt.check_password_hash(real_user.pw,request.form['pw']):
        flash('Invalid Email/Password!','err_user_pw_login')
        return redirect('/')
    session['uuid']=real_user.id
    return redirect('/user/dashboard/')


@app.route('/logout')
def logout():
    del session['uuid']
    return redirect('/')




@app.route('/newnew',methods=['POST'])
def new_food():
    if not Recipe.validator(request.form):
        return redirect('/create/recipe')
    data = {
        "name": request.form["name"],
        "description" : request.form["description"],
        "instructions" : request.form["instructions"],
        "thirty" : request.form['thirty'],
        "user_id":session['uuid'],
        "created_at" : request.form["created_at"]
    }
    Recipe.create(data)
    return redirect('/user/dashboard')