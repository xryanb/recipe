from flask import render_template,request, redirect,session,flash
from flask_app import app
from flask_app.models.recipe import Recipe
from flask_app.controllers import recipes
import re
from flask_app import Bcrypt
from flask_app.models.user import User

bcrypt = Bcrypt(app)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/create',methods=['POST'])
def create_user():
    if not User.validator(request.form):
        return redirect('/')

    pw_hash=bcrypt.generate_password_hash(request.form['pw'])
    data = {
        **request.form,
        "pw" : pw_hash
    }
    id=User.save(data)
    if not id:
        flash("Email already taken.")
        return redirect('/')
    session['uuid'] =id
    return redirect('/user/dashboard/')

@app.route('/user/dashboard/')
def results():
    if 'uuid' in session:
        user=User.get_one({'id':session['uuid']})
    if not 'uuid' in session:
        return render_template('display.html')
    users=Recipe.get_all()
    return render_template('display.html',user=user,users=users)

@app.route('/create/recipe/')
def new_recipe():
    if 'uuid' in session:
        user=User.get_one({'id':session['uuid']})
    if not 'uuid' in session:
        return render_template('create.html')
    return render_template('create.html',user=user)

#edit
@app.route('/user/edit/<int:id>')
def edit(id):
    if 'uuid' in session:
        user=User.get_one({'id':session['uuid']})
    if not 'uuid' in session:
        return redirect('/create/recipe/')
    data={"id":id}
    one_recipe=Recipe.get_one(data)
    return render_template("edit.html",one_recipe=one_recipe,user=user)

#update
@app.route('/user/update/<int:id>',methods=['POST'])
def update(id):
    if not Recipe.validator(request.form):
        flash('Must fill out form!','err_user_form')
        return redirect('/user/dashboard/')
    data={
        **request.form,
        "id":id,
        "user_id":session['uuid']
        
    }
    Recipe.update(data)
    return redirect('/user/dashboard/')

#show
@app.route('/user/recipes/<int:id>')
def show(id):
    if 'uuid' in session:
        user=User.get_one({'id':session['uuid']})
    if not 'uuid' in session:
        return render_template('display.html')
    data={"id":id}
    users=Recipe.get_one(data)
    return render_template("instructions.html",users=users,user=user)

#delete
@app.route('/user/delete/<int:id>')
def delete(id):
    data={
        "id":id
    }
    User.delete(data)
    return redirect('/user/dashboard/')
