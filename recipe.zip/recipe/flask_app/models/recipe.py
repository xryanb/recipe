from dataclasses import dataclass
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re
from flask_app.models.user import User
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
DATABASE='recipe'



class Recipe:
    def __init__(self,data):
        self.id=data['id']
        self.name=data['name']
        self.description = data['description']
        self.instructions = data['instructions']
        self.thirty = data['thirty']
        self.user_id = data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

        

    @classmethod
    def create(cls, data ):
        query = "INSERT INTO recipes( name , description, instructions,thirty,user_id, created_at, updated_at ) VALUES ( %(name)s , %(description)s , %(instructions)s ,%(thirty)s,%(user_id)s,%(created_at)s , NOW() );"
        ninja_id=connectToMySQL(DATABASE).query_db(query,data)
        return ninja_id


    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM recipes WHERE id=%(id)s;"
        results = connectToMySQL(DATABASE).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])


    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes;"
        results = connectToMySQL(DATABASE).query_db(query)
        users = []
        for user in results:
            users.append(cls(user))
        return users
    
    @classmethod
    def update(cls,data):
        query="UPDATE recipes SET name=%(name)s,description=%(description)s, instructions=%(instructions)s,thirty=%(thirty)s,user_id=%(user_id)s, updated_at=NOW() WHERE id=%(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)

    @classmethod
    def delete(cls,data):
        query="DELETE FROM recipes WHERE id=%(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)



    @staticmethod
    def validator(form_data:dict):
        is_valid = True
        if len(form_data['name']) <= 0:
            is_valid = False
            flash('Name is required! ','err_user_name')

        if len(form_data['description']) < 3:
            is_valid = False
            flash('Description Required!', 'err_user_description')

        if len(form_data['instructions']) < 3:
            is_valid = False
            flash('Instructions required!','err_user_instructions')
        
        if len(form_data['created_at']) < 1:
            is_valid = False
            flash('Date Required!','err_user_created_at')
        return is_valid

