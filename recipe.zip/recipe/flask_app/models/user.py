from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models import recipe
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

DATABASE='recipe'

class User:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.pw = data['pw']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.recipes=[]
        
    @property
    def fullname(self):
        return f"{self.first_name.capitalize()} {self.last_name.capitalize()}"

    @classmethod
    def save(cls,data):
        query = "INSERT INTO users (first_name,last_name,email,pw,created_at,updated_at) VALUES(%(first_name)s,%(last_name)s,%(email)s,%(pw)s,NOW(),NOW())"
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @classmethod
    def get_both( cls,data):
        query = "SELECT * FROM users LEFT JOIN recipes ON recipes.user_id = users.id WHERE users.id = %(id)s;"
        results = connectToMySQL(DATABASE).query_db( query , data )
        user = cls( results[0] )
        for row_from_db in results:
            recipe_data = {
                "id" : row_from_db["recipes.id"],
                "name" : row_from_db["name"],
                "description" : row_from_db["description"],
                "instructions" : row_from_db["instructions"],
                "thirty" : row_from_db["thirty"],
                "user_id":row_from_db['user_id'],
                "created_at" : row_from_db["recipes.created_at"],
                "updated_at" : row_from_db["recipes.updated_at"]
            }
            user.recipes.append(recipe.Recipe( recipe_data ) )
        return user


    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL(DATABASE).query_db(query)
        user = []
        for friend in results:
            user.append( cls(friend) )
        return user

    @classmethod
    def get_one(cls,data:dict):
        query = "SELECT * FROM users WHERE id=%(id)s;"
        results = connectToMySQL(DATABASE).query_db(query,data)
        return cls(results[0])

    @classmethod
    def get_one_by_email(cls,data:dict):
        query = "SELECT * FROM users WHERE email=%(email)s;"
        results = connectToMySQL(DATABASE).query_db(query,data)
        return User(results[0])

    
    @classmethod
    def delete(cls,data):
        query="DELETE FROM recipes WHERE id=%(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)

    @classmethod
    def update(cls,data):
        query="UPDATE recipes SET(name , description, instructions,thirty, updated_at ) VALUES (%(name)s , %(description)s , %(instructions)s ,%(thirty)s,NOW() ) WHERE id= %(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)

    @staticmethod
    def validator(form_data:dict):
        is_valid = True
        query = "SELECT * FROM users WHERE email=%(email)s;"
        results = connectToMySQL(DATABASE).query_db(query,form_data)

        if len(results) >=1:
            flash('Email already taken!','err_user_email')
            is_valid=False

        if len(form_data['first_name']) <= 0:
            is_valid = False
            flash('First Name is required! ','err_user_first')

        if len(form_data['last_name']) < 1:
            is_valid = False
            flash('Last Name required!', 'err_user_last')

        if len(form_data['email']) < 1:
            is_valid = False
            flash('Emailis required!','err_user_email')
        

        if len(form_data['pw']) <= 0:
            is_valid = False
            flash("pw is required,at least 8 characters long!.",'err_user_pw')
        pw1=form_data['pw']
        pw2=form_data['confirm']
        if pw1 != pw2 :
            is_valid = False
            flash("password needs to match!",'err_user_confirm')
        return is_valid

